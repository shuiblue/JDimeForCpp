int filesize=9;
void print(int a);
int write(String a);
String file="aaa";
void CardReader()
{
   filesize = 0;
   print(write(filesize));
   write();
   write(file,b);
}